name             'ntpd'
maintainer       'The Authors'
maintainer_email 'you@example.com'
license          'all_rights'
description      'Installs/Configures ntpd'
long_description 'Installs/Configures ntpd'
version          '0.1.0'

