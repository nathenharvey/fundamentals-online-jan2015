name             'git'
maintainer       'The Authors'
maintainer_email 'you@example.com'
license          'all_rights'
description      'Installs/Configures git'
long_description 'Installs/Configures git'
version          '0.1.0'

