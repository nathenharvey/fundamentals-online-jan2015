name             'motd'
maintainer       'The Authors'
maintainer_email 'you@example.com'
license          'all_rights'
description      'Installs/Configures motd'
long_description 'Installs/Configures motd'
version          '0.1.0'

