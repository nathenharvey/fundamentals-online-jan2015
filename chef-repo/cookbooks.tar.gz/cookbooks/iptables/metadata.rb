name             'iptables'
maintainer       'The Authors'
maintainer_email 'you@example.com'
license          'all_rights'
description      'Installs/Configures iptables'
long_description 'Installs/Configures iptables'
version          '0.1.0'

