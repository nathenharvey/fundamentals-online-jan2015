name             'apache'
maintainer       'The Authors'
maintainer_email 'you@example.com'
license          'all_rights'
description      'Installs/Configures apache'
long_description 'Installs/Configures apache'
version          '0.1.0'

